var n = navigator,
    isWebkit = false;

function onSuccess(stream) {
    var player1 = document.getElementById('player1'), // a video element
        player2 = document.getElementById('player2'),
        source;

    if (!isWebkit) {
        source = stream;
    } else {
        source = window.webkitURL.createObjectURL(stream);
    }

    player1.src = source;
    //player2.src = source;

    $(player1).addClass('sepia');
/*
    $(player2).addClass('sepia');
*/
}

function onError() {
    // womp, womp =(
}

if (n.getUserMedia) {
    // opera users (hopefully everyone else at some point)
    n.getUserMedia({video: true, audio: true}, onSuccess, onError);
} else if (n.webkitGetUserMedia) {
    // webkit users
    isWebkit = true;
    n.webkitGetUserMedia('video, audio', onSuccess, onError);
} else {
    // moms, dads, grandmas, and grandpas
}